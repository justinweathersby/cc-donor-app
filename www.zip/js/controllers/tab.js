'use strict'

app.controller('TabCtrl', function($scope, $state, $http) {
  console.log('tab');
  $scope.donateTab = true;
});
